package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.CatalogData
import com.example.model.ProductSize
import com.example.util.WhatsAppUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Deligurt", appName)
  }

  @Test
  fun `verify Fruping strict mandatory toppings rules`() {
    val fruping = CatalogData.PRODUCTS.find { it.id == "prod_fruping" }
    assertNotNull(fruping)
    assertEquals(3, fruping?.getRequiredToppingsCount(ProductSize.PEQUENO))
    assertEquals(5, fruping?.getRequiredToppingsCount(ProductSize.MEDIANO))
    assertEquals(7, fruping?.getRequiredToppingsCount(ProductSize.GRANDE))
  }

  @Test
  fun `verify WhatsApp message generation format`() {
    val message = WhatsAppUtil.generateWhatsAppMessage(
      customerName = "Laura Restrepo",
      customerPhone = "3109876543",
      address = "Carrera 7 # 120-20",
      neighborhood = "Usaquén",
      deliveryNotes = "Apto 501",
      paymentMethod = "Nequi",
      cashAmountToPayWith = null,
      cartItems = emptyList(),
      subtotal = 25000,
      deliveryFee = 4000,
      total = 29000
    )

    assertTrue(message.contains("DELIGURT APP"))
    assertTrue(message.contains("Laura Restrepo"))
    assertTrue(message.contains("Nequi"))
    assertTrue(message.contains("Usaquén"))
  }
}
