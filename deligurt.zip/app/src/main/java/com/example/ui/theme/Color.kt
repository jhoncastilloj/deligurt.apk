package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deligurt Brand Colors - Vibrant Mint & Creamy Yogurt
val MintPrimary = Color(0xFF00C49F)
val MintDark = Color(0xFF00967A)
val MintLight = Color(0xFFE6FBF5)
val MintGlow = Color(0xFF34D399)

val CreamBackground = Color(0xFFFAF7F2)
val CreamSurface = Color(0xFFFFFFFF)
val CreamCardBg = Color(0xFFFFFDF9)
val CreamDarker = Color(0xFFF3ECE0)

// Delightful Yogurt Accents
val StrawberryPink = Color(0xFFFF5A79)
val StrawberryLight = Color(0xFFFFEEF1)
val MangoPassion = Color(0xFFFFA500)
val MangoLight = Color(0xFFFFF7E6)
val BlueberryPurple = Color(0xFF8B5CF6)
val BlueberryLight = Color(0xFFF3E8FF)
val ChocoBrown = Color(0xFF78350F)
val ChocoLight = Color(0xFFFEF3C7)

// Spooky Deli-Ween Theme Accents
val DeliWeenPurple = Color(0xFF6B21A8)
val DeliWeenOrange = Color(0xFFEA580C)

// Clay Shadows & Highlights
val ClayShadowDark = Color(0x221E293B)
val ClayShadowLight = Color(0x60FFFFFF)
val ClayBorder = Color(0x18000000)

// Text Colors
val TextDark = Color(0xFF1E293B)
val TextMuted = Color(0xFF64748B)
val TextLight = Color(0xFF94A3B8)
val TextOnMint = Color(0xFFFFFFFF)
