package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CatalogData
import com.example.model.EdibleSpoonType
import com.example.model.Product
import com.example.model.ProductSize
import com.example.model.Topping
import com.example.model.ToppingCategory
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.CreamSurface
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.StrawberryPink
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnMint
import com.example.util.WhatsAppUtil

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProductCustomizationSheet(
  product: Product,
  selectedSize: ProductSize,
  selectedIncludedToppings: List<Topping>,
  selectedExtraToppings: List<Topping>,
  selectedEdibleSpoon: EdibleSpoonType,
  notes: String,
  validationWarning: String?,
  onDismiss: () -> Unit,
  onSizeChange: (ProductSize) -> Unit,
  onToggleTopping: (Topping) -> Unit,
  onEdibleSpoonChange: (EdibleSpoonType) -> Unit,
  onNotesChange: (String) -> Unit,
  onDismissValidation: () -> Unit,
  onAddToCart: () -> Unit,
  sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
  val requiredToppings = product.getRequiredToppingsCount(selectedSize)
  val isStrictProduct = requiredToppings > 0

  // Calculate live preview price
  val baseAndSize = product.basePrice + selectedSize.priceModifier
  val extrasCost = selectedExtraToppings.size * product.extraToppingPrice
  val spoonCost = selectedEdibleSpoon.price
  val currentTotal = baseAndSize + extrasCost + spoonCost

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = CreamBackground,
    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    dragHandle = null
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 24.dp)
    ) {
      // Top Sheet Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 22.dp, end = 14.dp, top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = product.emoji, fontSize = 28.sp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = product.name,
              fontSize = 20.sp,
              fontWeight = FontWeight.Black,
              color = TextDark
            )
            Text(
              text = product.category.displayName,
              fontSize = 12.sp,
              color = TextMuted
            )
          }
        }

        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("close_customization_button")
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Cerrar",
            tint = TextDark
          )
        }
      }

      // Scrollable Customization Content
      Column(
        modifier = Modifier
          .weight(1f, fill = false)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 6.dp)
      ) {
        // 1. SELECT SIZE (TAMAÑOS)
        Text(
          text = "1. Selecciona tu tamaño",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = TextDark
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          product.availableSizes.forEach { size ->
            val isSelected = size == selectedSize
            val reqForThisSize = product.getRequiredToppingsCount(size)

            ClayCard(
              modifier = Modifier
                .weight(1f)
                .testTag("size_option_${size.name.lowercase()}"),
              shape = RoundedCornerShape(20.dp),
              backgroundColor = if (isSelected) MintLight else Color.White,
              elevation = if (isSelected) 5.dp else 2.dp,
              onClick = { onSizeChange(size) }
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = size.displayName,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) MintDark else TextDark
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                  text = if (size.priceModifier == 0) "Base" else "+${WhatsAppUtil.formatCurrency(size.priceModifier)}",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = if (isSelected) MintPrimary else TextMuted
                )

                if (reqForThisSize > 0) {
                  Spacer(modifier = Modifier.height(4.dp))
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(8.dp))
                      .background(if (isSelected) MintPrimary else Color(0xFFF1F5F9))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = "$reqForThisSize toppings",
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (isSelected) TextOnMint else TextDark
                    )
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. STRICT TOPPINGS REQUIREMENTS STATUS (IF STRICT)
        if (isStrictProduct) {
          val currentCount = selectedIncludedToppings.size
          val progress = (currentCount.toFloat() / requiredToppings.toFloat()).coerceIn(0f, 1f)
          val isComplete = currentCount == requiredToppings

          ClayCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            backgroundColor = if (isComplete) Color(0xFFECFDF5) else Color(0xFFFFFBEB),
            elevation = 4.dp
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = if (isComplete) "✅" else "🎯",
                    fontSize = 18.sp
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (isComplete) "¡Toppings listos!" else "Regla de Toppings Obligatorios",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isComplete) MintDark else Color(0xFF92400E)
                  )
                }

                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isComplete) MintPrimary else Color(0xFFF59E0B))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                  Text(
                    text = "$currentCount / $requiredToppings elegidos",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = TextOnMint
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(8.dp)
                  .clip(RoundedCornerShape(4.dp)),
                color = if (isComplete) MintPrimary else Color(0xFFF59E0B),
                trackColor = Color.White
              )

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = if (isComplete) {
                  "Excelente: tienes exactamente los $requiredToppings toppings incluidos para tu tamaño ${selectedSize.displayName}."
                } else {
                  "Elige exactamente $requiredToppings toppings para tu ${product.name} ${selectedSize.displayName}. (Faltan ${requiredToppings - currentCount})"
                },
                fontSize = 12.sp,
                color = if (isComplete) MintDark else Color(0xFFB45309)
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))
        }

        // 3. TOPPINGS SELECTION (BY CATEGORY)
        if (product.allowsCustomToppings) {
          Text(
            text = "2. Elige tus Toppings",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )
          Text(
            text = if (isStrictProduct) {
              "Los primeros $requiredToppings son incluidos. Los siguientes son extra (+${WhatsAppUtil.formatCurrency(product.extraToppingPrice)} c/u)."
            } else {
              "Toppings frescos para acompañar tu helado."
            },
            fontSize = 12.sp,
            color = TextMuted
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Group by Category
          ToppingCategory.values().forEach { category ->
            Text(
              text = category.displayName,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = TextDark,
              modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)
            )

            val categoryToppings = CatalogData.TOPPINGS.filter { it.category == category }

            FlowRow(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              categoryToppings.forEach { topping ->
                val isIncluded = selectedIncludedToppings.any { it.id == topping.id }
                val isExtra = selectedExtraToppings.any { it.id == topping.id }
                val isSelected = isIncluded || isExtra

                ClayChip(
                  selected = isSelected,
                  onClick = { onToggleTopping(topping) },
                  activeColor = if (isExtra) StrawberryPink else MintPrimary,
                  inactiveColor = Color.White,
                  shape = RoundedCornerShape(16.dp),
                  modifier = Modifier.testTag("topping_${topping.id}")
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  ) {
                    Text(text = topping.iconEmoji, fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = topping.name,
                      fontSize = 13.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                      color = if (isSelected) TextOnMint else TextDark
                    )

                    if (isExtra) {
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = "(+${WhatsAppUtil.formatCurrency(product.extraToppingPrice)})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.9f)
                      )
                    } else if (isIncluded) {
                      Spacer(modifier = Modifier.width(4.dp))
                      Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Incluido",
                        tint = TextOnMint,
                        modifier = Modifier.size(14.dp)
                      )
                    }
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))
        }

        // 4. UPSELLING: EDIBLE SPOON (CUCHARA COMESTIBLE)
        if (product.allowsEdibleSpoon) {
          Text(
            text = "3. Cuchara Comestible Artesanal (Upsell)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )
          Text(
            text = "Ecológica, crujiente y deliciosa. ¡Cómela al terminar tu helado!",
            fontSize = 12.sp,
            color = TextMuted
          )

          Spacer(modifier = Modifier.height(10.dp))

          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            EdibleSpoonType.values().forEach { spoon ->
              val isSelected = spoon == selectedEdibleSpoon

              ClayCard(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("spoon_${spoon.name.lowercase()}"),
                shape = RoundedCornerShape(18.dp),
                backgroundColor = if (isSelected) MintLight else Color.White,
                elevation = if (isSelected) 4.dp else 2.dp,
                onClick = { onEdibleSpoonChange(spoon) }
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                      modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .border(
                          2.dp,
                          if (isSelected) MintPrimary else Color(0xFFCBD5E1),
                          CircleShape
                        )
                        .background(if (isSelected) MintPrimary else Color.Transparent),
                      contentAlignment = Alignment.Center
                    ) {
                      if (isSelected) {
                        Box(
                          modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                        )
                      }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                      text = spoon.displayName,
                      fontSize = 13.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      color = if (isSelected) MintDark else TextDark
                    )
                  }

                  Text(
                    text = if (spoon.price == 0) "$ 0" else "+${WhatsAppUtil.formatCurrency(spoon.price)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MintPrimary else TextMuted
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))
        }

        // 5. NOTAS ESPECIALES
        Text(
          text = "4. Instrucciones o Notas Especiales",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = TextDark
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = notes,
          onValueChange = onNotesChange,
          placeholder = { Text("Ej: Poner la salsa a un lado, poca galleta, etc.", fontSize = 13.sp) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("customization_notes_input"),
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MintPrimary,
            unfocusedBorderColor = Color(0xFFE2E8F0),
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
          ),
          maxLines = 2
        )

        Spacer(modifier = Modifier.height(20.dp))
      }

      // BOTTOM ADD TO CART BAR
      ClayCard(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 18.dp, vertical = 6.dp),
        shape = RoundedCornerShape(24.dp),
        backgroundColor = Color.White,
        elevation = 8.dp
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text(
              text = "Total a pagar",
              fontSize = 11.sp,
              color = TextMuted,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = WhatsAppUtil.formatCurrency(currentTotal),
              fontSize = 20.sp,
              fontWeight = FontWeight.Black,
              color = MintDark
            )
          }

          ClayButton(
            onClick = onAddToCart,
            backgroundColor = MintPrimary,
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp),
            modifier = Modifier.testTag("add_to_cart_confirm_button")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Añadir al Carrito",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextOnMint
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "🛒", fontSize = 14.sp)
            }
          }
        }
      }
    }
  }

  // 3D FRIENDLY VALIDATION MODAL (IF RULES NOT SATISFIED)
  if (validationWarning != null) {
    Dialog(onDismissRequest = onDismissValidation) {
      ClayCard(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
          .testTag("validation_alert_dialog"),
        shape = RoundedCornerShape(28.dp),
        backgroundColor = Color.White,
        elevation = 12.dp
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // 3D Visual Warning Container
          Box(
            modifier = Modifier
              .size(68.dp)
              .clip(CircleShape)
              .background(Color(0xFFFEF3C7)),
            contentAlignment = Alignment.Center
          ) {
            Text(text = "🍨✨", fontSize = 32.sp)
          }

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = "¡Personalicemos tu Helado!",
            fontSize = 19.sp,
            fontWeight = FontWeight.Black,
            color = TextDark,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = validationWarning,
            fontSize = 14.sp,
            color = Color(0xFF475569),
            textAlign = TextAlign.Center,
            lineHeight = 20.sp
          )

          Spacer(modifier = Modifier.height(22.dp))

          ClayButton(
            onClick = onDismissValidation,
            backgroundColor = MintPrimary,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("dismiss_validation_button")
          ) {
            Text(
              text = "¡Completar Toppings! 🍓",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextOnMint
            )
          }
        }
      }
    }
  }
}
