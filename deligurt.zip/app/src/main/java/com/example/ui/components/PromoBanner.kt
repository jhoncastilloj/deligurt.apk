package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CatalogData
import com.example.model.Product
import com.example.ui.theme.DeliWeenOrange
import com.example.ui.theme.DeliWeenPurple
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextOnMint

@Composable
fun PromoBanner(
  onSelectProduct: (Product) -> Unit,
  modifier: Modifier = Modifier
) {
  val deliWeen = CatalogData.PRODUCTS.firstOrNull { it.id == "prod_deli_ween" }

  ClayCard(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 18.dp),
    shape = RoundedCornerShape(26.dp),
    backgroundColor = Color(0xFFF3E8FF),
    elevation = 6.dp,
    onClick = {
      if (deliWeen != null) onSelectProduct(deliWeen)
    }
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.horizontalGradient(
            listOf(
              Color(0xFF2E1065),
              Color(0xFF581C87),
              Color(0xFF7E22CE)
            )
          )
        )
        .padding(18.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(DeliWeenOrange)
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "🎃 EDICIÓN ESPECIAL TEMPORADA",
              fontSize = 10.sp,
              fontWeight = FontWeight.Black,
              color = TextOnMint,
              letterSpacing = 0.5.sp
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Deli-Ween Spooky Swirl",
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextOnMint
          )

          Spacer(modifier = Modifier.height(3.dp))

          Text(
            text = "Yogurt morado de mora silvestre con cacao negro. ¡Toca para pedir!",
            fontSize = 12.sp,
            color = Color(0xFFE9D5FF),
            lineHeight = 16.sp
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // 3D Visual Emoji Badge
        Box(
          modifier = Modifier
            .size(64.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Text(text = "🎃🍨", fontSize = 32.sp)
        }
      }
    }
  }
}
