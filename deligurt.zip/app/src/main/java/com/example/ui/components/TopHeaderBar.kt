package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.StrawberryPink
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnMint

@Composable
fun TopHeaderBar(
  cartCount: Int,
  onOpenCart: () -> Unit,
  onOpenHistory: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 18.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // Brand Logo & Subtitle
    Row(verticalAlignment = Alignment.CenterVertically) {
      // 3D Clay Yogurt Icon Container
      ClayCard(
        modifier = Modifier.size(46.dp),
        shape = RoundedCornerShape(16.dp),
        backgroundColor = MintLight,
        elevation = 4.dp
      ) {
        Box(
          modifier = Modifier.matchParentSize(),
          contentAlignment = Alignment.Center
        ) {
          Text(text = "🍨", fontSize = 24.sp)
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "Deligurt",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = TextDark,
            letterSpacing = (-0.5).sp
          )
          Spacer(modifier = Modifier.width(6.dp))
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(MintPrimary)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "APP",
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = TextOnMint
            )
          }
        }
        Text(
          text = "Yogurt Cremoso & Sodas",
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          color = TextMuted
        )
      }
    }

    // Actions: History & Cart
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Order History Button
      ClayCard(
        modifier = Modifier
          .size(44.dp)
          .testTag("history_button"),
        shape = RoundedCornerShape(14.dp),
        backgroundColor = Color(0xFFF8F5EE),
        elevation = 3.dp,
        onClick = onOpenHistory
      ) {
        Box(
          modifier = Modifier.matchParentSize(),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.History,
            contentDescription = "Historial de Pedidos",
            tint = TextDark,
            modifier = Modifier.size(22.dp)
          )
        }
      }

      // Cart Button with Count Badge
      ClayCard(
        modifier = Modifier
          .size(44.dp)
          .testTag("cart_button"),
        shape = RoundedCornerShape(14.dp),
        backgroundColor = if (cartCount > 0) MintPrimary else Color(0xFFF8F5EE),
        elevation = if (cartCount > 0) 5.dp else 3.dp,
        onClick = onOpenCart
      ) {
        Box(
          modifier = Modifier.matchParentSize(),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.ShoppingBag,
            contentDescription = "Carrito de Compras",
            tint = if (cartCount > 0) TextOnMint else TextDark,
            modifier = Modifier.size(22.dp)
          )

          if (cartCount > 0) {
            Box(
              modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 4.dp, y = (-4).dp)
                .clip(CircleShape)
                .background(StrawberryPink)
                .padding(horizontal = 5.dp, vertical = 2.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = cartCount.toString(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                color = TextOnMint
              )
            }
          }
        }
      }
    }
  }
}
