package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CartItemEntity
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.StrawberryPink
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnMint
import com.example.util.WhatsAppUtil

data class PaymentOption(
  val id: String,
  val name: String,
  val iconEmoji: String,
  val brandColor: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutSheet(
  customerName: String,
  customerPhone: String,
  customerAddress: String,
  customerNeighborhood: String,
  deliveryNotes: String,
  paymentMethod: String,
  cashAmountToPay: String,
  cartItems: List<CartItemEntity>,
  subtotal: Int,
  deliveryFee: Int,
  total: Int,
  onNameChange: (String) -> Unit,
  onPhoneChange: (String) -> Unit,
  onAddressChange: (String) -> Unit,
  onNeighborhoodChange: (String) -> Unit,
  onNotesChange: (String) -> Unit,
  onPaymentMethodChange: (String) -> Unit,
  onCashAmountChange: (String) -> Unit,
  onDismiss: () -> Unit,
  onSubmitOrder: () -> Unit,
  sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
  val context = LocalContext.current
  var validationError by remember { mutableStateOf<String?>(null) }
  var showPreviewMessage by remember { mutableStateOf(false) }

  val paymentOptions = listOf(
    PaymentOption("Nequi", "Nequi", "🟣", Color(0xFF4A154B)),
    PaymentOption("Daviplata", "Daviplata", "🔴", Color(0xFFED1C24)),
    PaymentOption("Bancolombia", "Bancolombia", "🟡", Color(0xFFFDDA24)),
    PaymentOption("Efectivo", "Efectivo", "💵", Color(0xFF15803D))
  )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = CreamBackground,
    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    dragHandle = null
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 24.dp)
    ) {
      // Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 22.dp, end = 14.dp, top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = "💬", fontSize = 24.sp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Finalizar Pedido",
              fontSize = 20.sp,
              fontWeight = FontWeight.Black,
              color = TextDark
            )
            Text(
              text = "Despacho directo por WhatsApp",
              fontSize = 12.sp,
              color = TextMuted
            )
          }
        }

        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("close_checkout_button")
        ) {
          Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = TextDark)
        }
      }

      // Scrollable Form
      Column(
        modifier = Modifier
          .weight(1f, fill = false)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 6.dp)
      ) {
        // Validation Error if any
        if (validationError != null) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(Color(0xFFFFEEF1))
              .padding(12.dp)
          ) {
            Text(
              text = "⚠️ $validationError",
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              color = StrawberryPink
            )
          }
          Spacer(modifier = Modifier.height(14.dp))
        }

        // 1. DATOS DEL CLIENTE
        Text(
          text = "1. Tus Datos de Entrega",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = TextDark
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = customerName,
          onValueChange = {
            onNameChange(it)
            if (validationError != null) validationError = null
          },
          label = { Text("Nombre Completo *") },
          placeholder = { Text("Ej: Andrea Gómez") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("checkout_name_input"),
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MintPrimary,
            unfocusedBorderColor = Color(0xFFE2E8F0),
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
          ),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = customerPhone,
          onValueChange = onPhoneChange,
          label = { Text("Teléfono de Contacto (opcional)") },
          placeholder = { Text("Ej: 300 123 4567") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("checkout_phone_input"),
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MintPrimary,
            unfocusedBorderColor = Color(0xFFE2E8F0),
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
          ),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedTextField(
            value = customerAddress,
            onValueChange = {
              onAddressChange(it)
              if (validationError != null) validationError = null
            },
            label = { Text("Dirección *") },
            placeholder = { Text("Calle 45 # 23-10") },
            modifier = Modifier
              .weight(1.3f)
              .testTag("checkout_address_input"),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MintPrimary,
              unfocusedBorderColor = Color(0xFFE2E8F0),
              focusedContainerColor = Color.White,
              unfocusedContainerColor = Color.White
            ),
            singleLine = true
          )

          OutlinedTextField(
            value = customerNeighborhood,
            onValueChange = onNeighborhoodChange,
            label = { Text("Barrio") },
            placeholder = { Text("El Prado") },
            modifier = Modifier
              .weight(1f)
              .testTag("checkout_neighborhood_input"),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MintPrimary,
              unfocusedBorderColor = Color(0xFFE2E8F0),
              focusedContainerColor = Color.White,
              unfocusedContainerColor = Color.White
            ),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = deliveryNotes,
          onValueChange = onNotesChange,
          label = { Text("Instrucciones de Entrega (opcional)") },
          placeholder = { Text("Ej: Apto 302, torre 1. Tocar citófono.") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("checkout_notes_input"),
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MintPrimary,
            unfocusedBorderColor = Color(0xFFE2E8F0),
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
          ),
          maxLines = 2
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 2. MÉTODO DE PAGO 3D CLAY BUTTONS
        Text(
          text = "2. Selecciona Método de Pago",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = TextDark
        )
        Text(
          text = "Opciones locales rápidas sin comisiones",
          fontSize = 12.sp,
          color = TextMuted
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          paymentOptions.forEach { option ->
            val isSelected = option.id == paymentMethod

            ClayCard(
              modifier = Modifier
                .weight(1f)
                .testTag("payment_${option.id.lowercase()}"),
              shape = RoundedCornerShape(18.dp),
              backgroundColor = if (isSelected) MintLight else Color.White,
              elevation = if (isSelected) 5.dp else 2.dp,
              onClick = { onPaymentMethodChange(option.id) }
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 12.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(text = option.iconEmoji, fontSize = 20.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = option.name,
                  fontSize = 11.sp,
                  fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                  color = if (isSelected) MintDark else TextDark,
                  maxLines = 1
                )
              }
            }
          }
        }

        // If Cash (Efectivo) is selected: prompt for change
        AnimatedVisibility(visible = paymentMethod == "Efectivo") {
          Column(modifier = Modifier.padding(top = 10.dp)) {
            OutlinedTextField(
              value = cashAmountToPay,
              onValueChange = onCashAmountChange,
              label = { Text("¿Con cuánto billete pagas?") },
              placeholder = { Text("Ej: $50.000 para llevarte cambio exacto") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("checkout_cash_change_input"),
              shape = RoundedCornerShape(16.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MintPrimary,
                unfocusedBorderColor = Color(0xFFE2E8F0),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White
              ),
              singleLine = true
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // ORDER SUMMARY BREAKDOWN CARD
        ClayCard(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          backgroundColor = Color.White,
          elevation = 4.dp
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp)
          ) {
            Text(
              text = "Resumen (${cartItems.size} productos)",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextDark
            )
            Spacer(modifier = Modifier.height(6.dp))

            cartItems.forEach { item ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "${item.quantity}x ${item.productName} (${item.sizeName})",
                  fontSize = 12.sp,
                  color = TextMuted,
                  modifier = Modifier.weight(1f)
                )
                Text(
                  text = WhatsAppUtil.formatCurrency(item.totalPrice),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = TextDark
                )
              }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Domicilio", fontSize = 12.sp, color = TextMuted)
              Text(
                text = if (deliveryFee == 0) "¡GRATIS!" else WhatsAppUtil.formatCurrency(deliveryFee),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (deliveryFee == 0) MintDark else TextDark
              )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(text = "Total a Pagar", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDark)
              Text(
                text = WhatsAppUtil.formatCurrency(total),
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = MintDark
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Preview Message Toggle Button
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center
        ) {
          androidx.compose.material3.TextButton(
            onClick = { showPreviewMessage = !showPreviewMessage }
          ) {
            Text(
              text = if (showPreviewMessage) "Ocultar mensaje WhatsApp" else "Ver vista previa del mensaje WhatsApp 👁️",
              fontSize = 12.sp,
              color = MintDark,
              fontWeight = FontWeight.Bold
            )
          }
        }

        AnimatedVisibility(visible = showPreviewMessage) {
          val previewText = WhatsAppUtil.generateWhatsAppMessage(
            customerName = if (customerName.isBlank()) "Tu Nombre" else customerName,
            customerPhone = customerPhone,
            address = if (customerAddress.isBlank()) "Tu Dirección" else customerAddress,
            neighborhood = customerNeighborhood,
            deliveryNotes = deliveryNotes,
            paymentMethod = paymentMethod,
            cashAmountToPayWith = if (paymentMethod == "Efectivo") cashAmountToPay else null,
            cartItems = cartItems,
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            total = total
          )

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .background(Color(0xFFE7FCEE))
              .padding(14.dp)
          ) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Mensaje a enviar:",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F5132)
                )
                IconButton(
                  onClick = {
                    WhatsAppUtil.copyToClipboard(context, previewText)
                    android.widget.Toast.makeText(context, "Copiado al portapapeles", android.widget.Toast.LENGTH_SHORT).show()
                  },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(
                    Icons.Default.ContentCopy,
                    contentDescription = "Copiar",
                    tint = Color(0xFF0F5132),
                    modifier = Modifier.size(16.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = previewText,
                fontSize = 11.sp,
                color = Color(0xFF14532D),
                lineHeight = 16.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))
      }

      // CONFIRM AND SEND BUTTON
      ClayCard(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 18.dp),
        shape = RoundedCornerShape(24.dp),
        backgroundColor = Color.White,
        elevation = 8.dp
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          ClayButton(
            onClick = {
              if (customerName.trim().isBlank()) {
                validationError = "Por favor ingresa tu nombre completo."
                return@ClayButton
              }
              if (customerAddress.trim().isBlank()) {
                validationError = "Por favor ingresa tu dirección de entrega."
                return@ClayButton
              }
              onSubmitOrder()
            },
            backgroundColor = Color(0xFF25D366), // WhatsApp brand green
            modifier = Modifier
              .fillMaxWidth()
              .testTag("submit_order_whatsapp_button")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = "📲", fontSize = 18.sp)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Enviar Pedido a WhatsApp",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextOnMint
              )
            }
          }
        }
      }
    }
  }
}
