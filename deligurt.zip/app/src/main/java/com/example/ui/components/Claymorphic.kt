package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ClayShadowDark
import com.example.ui.theme.ClayShadowLight
import com.example.ui.theme.CreamCardBg
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextOnMint

/**
 * 3D Claymorphic Card container with soft highlights, diffused shadows, and tactile physics.
 */
@Composable
fun ClayCard(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(24.dp),
  backgroundColor: Color = CreamCardBg,
  highlightColor: Color = ClayShadowLight,
  elevation: Dp = 8.dp,
  borderStrokeWidth: Dp = 1.5.dp,
  onClick: (() -> Unit)? = null,
  content: @Composable BoxScope.() -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val haptic = LocalHapticFeedback.current

  val scale by animateFloatAsState(
    targetValue = if (isPressed && onClick != null) 0.97f else 1.0f,
    animationSpec = spring(dampingRatio = 0.65f, stiffness = 400f),
    label = "clayCardScale"
  )

  val currentElevation = if (isPressed && onClick != null) (elevation / 3) else elevation

  Box(
    modifier = modifier
      .scale(scale)
      .shadow(
        elevation = currentElevation,
        shape = shape,
        ambientColor = ClayShadowDark,
        spotColor = ClayShadowDark
      )
      .clip(shape)
      .background(backgroundColor)
      .border(
        BorderStroke(
          borderStrokeWidth,
          Brush.verticalGradient(
            listOf(highlightColor, Color(0x10000000))
          )
        ),
        shape = shape
      )
      .then(
        if (onClick != null) {
          Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = {
              haptic.performHapticFeedback(HapticFeedbackType.LongPress)
              onClick()
            }
          )
        } else Modifier
      ),
    content = content
  )
}

/**
 * 3D Clay Button with satisfying tactile spring press effect and gradient fill.
 */
@Composable
fun ClayButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  backgroundColor: Color = MintPrimary,
  contentColor: Color = TextOnMint,
  shape: Shape = RoundedCornerShape(20.dp),
  elevation: Dp = 6.dp,
  contentPadding: PaddingValues = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
  content: @Composable () -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val haptic = LocalHapticFeedback.current

  val scale by animateFloatAsState(
    targetValue = if (isPressed && enabled) 0.94f else 1.0f,
    animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
    label = "clayButtonScale"
  )

  val currentElevation = if (isPressed || !enabled) 1.dp else elevation
  val effectiveColor = if (enabled) backgroundColor else Color(0xFFCBD5E1)

  Box(
    modifier = modifier
      .scale(scale)
      .defaultMinSize(minHeight = 48.dp)
      .shadow(
        elevation = currentElevation,
        shape = shape,
        ambientColor = if (enabled) effectiveColor.copy(alpha = 0.5f) else Color.Transparent,
        spotColor = if (enabled) effectiveColor.copy(alpha = 0.6f) else Color.Transparent
      )
      .clip(shape)
      .background(
        Brush.verticalGradient(
          listOf(
            effectiveColor.copy(alpha = if (enabled) 0.95f else 0.7f),
            effectiveColor
          )
        )
      )
      .border(
        BorderStroke(
          1.5.dp,
          Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.45f), Color.Transparent)
          )
        ),
        shape = shape
      )
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        enabled = enabled,
        onClick = {
          haptic.performHapticFeedback(HapticFeedbackType.LongPress)
          onClick()
        }
      )
      .padding(contentPadding),
    contentAlignment = Alignment.Center
  ) {
    content()
  }
}

/**
 * 3D Clay Chip for Toppings and Sizes with active and pressed sunken state.
 */
@Composable
fun ClayChip(
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  activeColor: Color = MintPrimary,
  inactiveColor: Color = Color(0xFFF8F5EE),
  shape: Shape = RoundedCornerShape(16.dp),
  content: @Composable () -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val haptic = LocalHapticFeedback.current

  val scale by animateFloatAsState(
    targetValue = if (isPressed) 0.92f else 1.0f,
    animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
    label = "clayChipScale"
  )

  val elevation = if (selected) 4.dp else 2.dp
  val currentElevation = if (isPressed) 0.dp else elevation

  Box(
    modifier = modifier
      .scale(scale)
      .defaultMinSize(minHeight = 44.dp)
      .shadow(
        elevation = currentElevation,
        shape = shape,
        ambientColor = if (selected) activeColor.copy(alpha = 0.4f) else ClayShadowDark,
        spotColor = if (selected) activeColor.copy(alpha = 0.45f) else ClayShadowDark
      )
      .clip(shape)
      .background(if (selected) activeColor else inactiveColor)
      .border(
        BorderStroke(
          1.5.dp,
          if (selected) {
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.5f), activeColor))
          } else {
            Brush.verticalGradient(listOf(Color.White, Color(0x18000000)))
          }
        ),
        shape = shape
      )
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = {
          haptic.performHapticFeedback(HapticFeedbackType.LongPress)
          onClick()
        }
      )
      .padding(horizontal = 14.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center
  ) {
    content()
  }
}

/**
 * 3D Clay Badge for special tags (e.g. Edición Especial, Más Pedido)
 */
@Composable
fun ClayBadge(
  text: String,
  modifier: Modifier = Modifier,
  backgroundColor: Color = MintPrimary,
  textColor: Color = TextOnMint
) {
  Box(
    modifier = modifier
      .shadow(2.dp, RoundedCornerShape(12.dp), spotColor = backgroundColor.copy(alpha = 0.5f))
      .clip(RoundedCornerShape(12.dp))
      .background(backgroundColor)
      .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)), RoundedCornerShape(12.dp))
      .padding(horizontal = 10.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = text,
      color = textColor,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold
    )
  }
}
