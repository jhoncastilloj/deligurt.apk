package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CategoryTabs
import com.example.ui.components.ClayButton
import com.example.ui.components.ClayCard
import com.example.ui.components.CartSheet
import com.example.ui.components.CheckoutSheet
import com.example.ui.components.OrderHistorySheet
import com.example.ui.components.ProductCard
import com.example.ui.components.ProductCustomizationSheet
import com.example.ui.components.PromoBanner
import com.example.ui.components.TopHeaderBar
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnMint
import androidx.compose.material3.ExperimentalMaterial3Api
import com.example.util.WhatsAppUtil
import com.example.viewmodel.DeligurtViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: DeligurtViewModel) {
  val context = LocalContext.current

  val selectedCategory by viewModel.selectedCategory.collectAsState()
  val searchQuery by viewModel.searchQuery.collectAsState()
  val products by viewModel.products.collectAsState()

  val cartItems by viewModel.cartItems.collectAsState()
  val cartSubtotal by viewModel.cartSubtotal.collectAsState()
  val deliveryFee by viewModel.deliveryFee.collectAsState()
  val cartTotal by viewModel.cartTotal.collectAsState()
  val cartItemCount by viewModel.cartItemCount.collectAsState()
  val orderHistory by viewModel.orderHistory.collectAsState()

  val customizingProduct by viewModel.customizingProduct.collectAsState()
  val selectedSize by viewModel.selectedSize.collectAsState()
  val selectedIncludedToppings by viewModel.selectedIncludedToppings.collectAsState()
  val selectedExtraToppings by viewModel.selectedExtraToppings.collectAsState()
  val selectedEdibleSpoon by viewModel.selectedEdibleSpoon.collectAsState()
  val customizationNotes by viewModel.customizationNotes.collectAsState()
  val validationDialogMessage by viewModel.validationDialogMessage.collectAsState()

  val isCartSheetOpen by viewModel.isCartSheetOpen.collectAsState()
  val isCheckoutOpen by viewModel.isCheckoutOpen.collectAsState()
  val isHistoryOpen by viewModel.isHistoryOpen.collectAsState()

  val customerName by viewModel.customerName.collectAsState()
  val customerPhone by viewModel.customerPhone.collectAsState()
  val customerAddress by viewModel.customerAddress.collectAsState()
  val customerNeighborhood by viewModel.customerNeighborhood.collectAsState()
  val deliveryNotes by viewModel.deliveryNotes.collectAsState()
  val paymentMethod by viewModel.paymentMethod.collectAsState()
  val cashAmountToPay by viewModel.cashAmountToPay.collectAsState()

  val filteredProducts = if (searchQuery.isBlank()) {
    products
  } else {
    products.filter {
      it.name.contains(searchQuery, ignoreCase = true) ||
          it.description.contains(searchQuery, ignoreCase = true)
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .background(CreamBackground)
      .statusBarsPadding(),
    containerColor = CreamBackground,
    bottomBar = {
      // Floating 3D Clay Cart Bar (shown when cart has items and not in modal)
      AnimatedVisibility(
        visible = cartItemCount > 0 && !isCartSheetOpen && !isCheckoutOpen,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it })
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
          ClayCard(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("floating_cart_bar"),
            shape = RoundedCornerShape(26.dp),
            backgroundColor = MintPrimary,
            elevation = 10.dp,
            onClick = { viewModel.openCart() }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f)),
                  contentAlignment = Alignment.Center
                ) {
                  Text(text = "🛒", fontSize = 18.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                  Text(
                    text = "$cartItemCount ${if (cartItemCount == 1) "producto" else "productos"}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.9f)
                  )
                  Text(
                    text = WhatsAppUtil.formatCurrency(cartTotal),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = TextOnMint
                  )
                }
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Ver Pedido",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextOnMint
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "👉", fontSize = 14.sp)
              }
            }
          }
        }
      }
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues),
      contentPadding = PaddingValues(bottom = if (cartItemCount > 0) 90.dp else 24.dp)
    ) {
      // 1. Top Header
      item {
        TopHeaderBar(
          cartCount = cartItemCount,
          onOpenCart = { viewModel.openCart() },
          onOpenHistory = { viewModel.openHistory() }
        )
      }

      // 2. Search / Filter Field
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 6.dp)
        ) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Buscar sabor, topping o soda...", fontSize = 13.sp, color = TextMuted) },
            leadingIcon = {
              Icon(Icons.Default.Search, contentDescription = "Buscar", tint = TextMuted)
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("search_input"),
            shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MintPrimary,
              unfocusedBorderColor = Color(0xFFE2E8F0),
              focusedContainerColor = Color.White,
              unfocusedContainerColor = Color.White
            ),
            singleLine = true
          )
        }
      }

      // 3. Featured Promo Banner (Deli-Ween & Seasonal)
      item {
        Spacer(modifier = Modifier.height(6.dp))
        PromoBanner(
          onSelectProduct = { product -> viewModel.openCustomization(product) }
        )
        Spacer(modifier = Modifier.height(10.dp))
      }

      // 4. Category Tabs
      item {
        CategoryTabs(
          selectedCategory = selectedCategory,
          onCategorySelected = { viewModel.setCategory(it) }
        )
        Spacer(modifier = Modifier.height(6.dp))
      }

      // 5. Products List
      if (filteredProducts.isEmpty()) {
        item {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(text = "🍨🔍", fontSize = 36.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "No encontramos productos",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = TextDark
            )
            Text(
              text = "Prueba con otra búsqueda o cambia de categoría.",
              fontSize = 13.sp,
              color = TextMuted
            )
          }
        }
      } else {
        items(filteredProducts, key = { it.id }) { product ->
          Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
            ProductCard(
              product = product,
              onCustomizeClick = { viewModel.openCustomization(product) }
            )
          }
        }
      }
    }
  }

  // CUSTOMIZATION SHEET
  customizingProduct?.let { product ->
    ProductCustomizationSheet(
      product = product,
      selectedSize = selectedSize,
      selectedIncludedToppings = selectedIncludedToppings,
      selectedExtraToppings = selectedExtraToppings,
      selectedEdibleSpoon = selectedEdibleSpoon,
      notes = customizationNotes,
      validationWarning = validationDialogMessage,
      onDismiss = { viewModel.closeCustomization() },
      onSizeChange = { viewModel.setSize(it) },
      onToggleTopping = { viewModel.toggleTopping(it) },
      onEdibleSpoonChange = { viewModel.setEdibleSpoon(it) },
      onNotesChange = { viewModel.setCustomizationNotes(it) },
      onDismissValidation = { viewModel.dismissValidationDialog() },
      onAddToCart = { viewModel.confirmAddToCart() }
    )
  }

  // CART SHEET
  if (isCartSheetOpen) {
    CartSheet(
      cartItems = cartItems,
      subtotal = cartSubtotal,
      deliveryFee = deliveryFee,
      total = cartTotal,
      onDismiss = { viewModel.closeCart() },
      onUpdateQuantity = { id, qty -> viewModel.updateCartItemQuantity(id, qty) },
      onRemoveItem = { id -> viewModel.removeCartItem(id) },
      onClearCart = { viewModel.clearCart() },
      onProceedToCheckout = { viewModel.openCheckout() }
    )
  }

  // CHECKOUT SHEET
  if (isCheckoutOpen) {
    CheckoutSheet(
      customerName = customerName,
      customerPhone = customerPhone,
      customerAddress = customerAddress,
      customerNeighborhood = customerNeighborhood,
      deliveryNotes = deliveryNotes,
      paymentMethod = paymentMethod,
      cashAmountToPay = cashAmountToPay,
      cartItems = cartItems,
      subtotal = cartSubtotal,
      deliveryFee = deliveryFee,
      total = cartTotal,
      onNameChange = { viewModel.customerName.value = it },
      onPhoneChange = { viewModel.customerPhone.value = it },
      onAddressChange = { viewModel.customerAddress.value = it },
      onNeighborhoodChange = { viewModel.customerNeighborhood.value = it },
      onNotesChange = { viewModel.deliveryNotes.value = it },
      onPaymentMethodChange = { viewModel.paymentMethod.value = it },
      onCashAmountChange = { viewModel.cashAmountToPay.value = it },
      onDismiss = { viewModel.closeCheckout() },
      onSubmitOrder = { viewModel.submitOrderToWhatsApp(context) }
    )
  }

  // ORDER HISTORY SHEET
  if (isHistoryOpen) {
    OrderHistorySheet(
      orderHistory = orderHistory,
      onDismiss = { viewModel.closeHistory() },
      onReorder = { order -> viewModel.reorderPreviousOrder(order) }
    )
  }
}
