package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OrderEntity
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnMint
import com.example.util.WhatsAppUtil
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderHistorySheet(
  orderHistory: List<OrderEntity>,
  onDismiss: () -> Unit,
  onReorder: (OrderEntity) -> Unit,
  sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
  val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale("es", "CO"))

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = CreamBackground,
    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    dragHandle = null
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 24.dp)
    ) {
      // Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 22.dp, end = 14.dp, top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = "📜", fontSize = 24.sp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Historial de Pedidos",
              fontSize = 20.sp,
              fontWeight = FontWeight.Black,
              color = TextDark
            )
            Text(
              text = "Tus pedidos enviados a WhatsApp",
              fontSize = 12.sp,
              color = TextMuted
            )
          }
        }

        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("close_history_button")
        ) {
          Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = TextDark)
        }
      }

      if (orderHistory.isEmpty()) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(
            modifier = Modifier
              .size(70.dp)
              .clip(CircleShape)
              .background(MintLight),
            contentAlignment = Alignment.Center
          ) {
            Text(text = "🍨", fontSize = 36.sp)
          }

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = "Sin pedidos anteriores",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Tus pedidos enviados a WhatsApp aparecerán guardados aquí para que puedas reordenar en 1 clic.",
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .weight(1f, fill = false)
            .padding(horizontal = 18.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(orderHistory, key = { it.orderId }) { order ->
            ClayCard(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("order_history_item_${order.orderId}"),
              shape = RoundedCornerShape(20.dp),
              backgroundColor = Color.White,
              elevation = 4.dp
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "#${order.orderId}",
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Black,
                      color = MintDark
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    ClayBadge(
                      text = order.status,
                      backgroundColor = Color(0xFF25D366)
                    )
                  }

                  Text(
                    text = dateFormat.format(Date(order.timestamp)),
                    fontSize = 11.sp,
                    color = TextMuted
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                  text = order.itemsSummary,
                  fontSize = 13.sp,
                  color = TextDark,
                  lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "Pago: ${order.paymentMethod} • Total: ${WhatsAppUtil.formatCurrency(order.total)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF475569)
                  )

                  ClayButton(
                    onClick = { onReorder(order) },
                    backgroundColor = MintPrimary,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("reorder_button_${order.orderId}")
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reordenar",
                        tint = TextOnMint,
                        modifier = Modifier.size(14.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = "Pedir de nuevo",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextOnMint
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
