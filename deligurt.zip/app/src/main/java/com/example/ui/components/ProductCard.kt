package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Product
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.StrawberryPink
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnMint
import com.example.util.WhatsAppUtil

@Composable
fun ProductCard(
  product: Product,
  onCustomizeClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  ClayCard(
    modifier = modifier
      .fillMaxWidth()
      .testTag("product_card_${product.id}"),
    shape = RoundedCornerShape(26.dp),
    backgroundColor = Color(0xFFFFFDF9),
    elevation = 6.dp,
    onClick = onCustomizeClick
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Emoji & Visual 3D Container
        Box(
          modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Color(product.accentColorHex).copy(alpha = 0.12f)),
          contentAlignment = Alignment.Center
        ) {
          Text(text = product.emoji, fontSize = 38.sp)
        }

        Spacer(modifier = Modifier.width(14.dp))

        // Product Details
        Column(modifier = Modifier.weight(1f)) {
          // Badge if any
          if (!product.badge.isNullOrBlank()) {
            ClayBadge(
              text = product.badge,
              backgroundColor = if (product.isLimitedEdition) Color(0xFF6B21A8) else MintPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
          }

          Text(
            text = product.name,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = product.description,
            fontSize = 13.sp,
            color = TextMuted,
            lineHeight = 17.sp,
            maxLines = 3
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Strict Conditions Indicator Bar if applicable
      if (product.hasStrictToppingRules()) {
        val rulesSummary = product.mandatoryToppingsRules?.entries?.joinToString(" • ") {
          "${it.key.displayName.take(3)}: ${it.value}"
        } ?: ""

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MintLight)
            .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "🎯", fontSize = 12.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Toppings incluidos: $rulesSummary",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = MintDark
            )
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
      }

      // Price and Action Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(
            text = "Desde",
            fontSize = 11.sp,
            color = TextMuted,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = WhatsAppUtil.formatCurrency(product.basePrice),
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = MintDark
          )
        }

        ClayButton(
          onClick = onCustomizeClick,
          backgroundColor = MintPrimary,
          shape = RoundedCornerShape(16.dp),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 18.dp, vertical = 10.dp),
          modifier = Modifier.testTag("customize_button_${product.id}")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = if (product.allowsCustomToppings) "Personalizar" else "Pedir",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextOnMint
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "✨", fontSize = 12.sp)
          }
        }
      }
    }
  }
}
