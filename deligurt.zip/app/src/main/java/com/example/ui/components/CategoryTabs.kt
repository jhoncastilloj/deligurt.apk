package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ProductCategory
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextOnMint

@Composable
fun CategoryTabs(
  selectedCategory: ProductCategory,
  onCategorySelected: (ProductCategory) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 18.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    ProductCategory.values().forEach { category ->
      val isSelected = category == selectedCategory

      ClayChip(
        selected = isSelected,
        onClick = { onCategorySelected(category) },
        shape = RoundedCornerShape(20.dp),
        activeColor = MintPrimary,
        inactiveColor = Color(0xFFFBF8F2),
        modifier = Modifier.testTag("category_tab_${category.name.lowercase()}")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
          Text(text = category.icon, fontSize = 16.sp)
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = category.displayName,
            fontSize = 14.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) TextOnMint else TextDark
          )
        }
      }
    }
  }
}
