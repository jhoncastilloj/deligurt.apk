package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CartItemEntity
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintPrimary
import com.example.ui.theme.StrawberryPink
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnMint
import com.example.util.WhatsAppUtil

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartSheet(
  cartItems: List<CartItemEntity>,
  subtotal: Int,
  deliveryFee: Int,
  total: Int,
  onDismiss: () -> Unit,
  onUpdateQuantity: (id: Long, qty: Int) -> Unit,
  onRemoveItem: (id: Long) -> Unit,
  onClearCart: () -> Unit,
  onProceedToCheckout: () -> Unit,
  sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = CreamBackground,
    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    dragHandle = null
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 24.dp)
    ) {
      // Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 22.dp, end = 14.dp, top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = "🛒", fontSize = 24.sp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Tu Carrito Deligurt",
              fontSize = 20.sp,
              fontWeight = FontWeight.Black,
              color = TextDark
            )
            Text(
              text = "Guardado localmente en tu dispositivo",
              fontSize = 11.sp,
              color = TextMuted
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (cartItems.isNotEmpty()) {
            TextButton(
              onClick = onClearCart,
              modifier = Modifier.testTag("clear_cart_button")
            ) {
              Text("Vaciar", color = StrawberryPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
          IconButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("close_cart_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = TextDark)
          }
        }
      }

      if (cartItems.isEmpty()) {
        // Empty State
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(
            modifier = Modifier
              .size(80.dp)
              .clip(CircleShape)
              .background(MintLight),
            contentAlignment = Alignment.Center
          ) {
            Text(text = "🍨", fontSize = 42.sp)
          }

          Spacer(modifier = Modifier.height(18.dp))

          Text(
            text = "Tu carrito está vacío",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Agrega tus helados favoritos con toppings personalizados para pedir a domicilio.",
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(20.dp))

          ClayButton(
            onClick = onDismiss,
            backgroundColor = MintPrimary,
            modifier = Modifier.testTag("explore_menu_empty_button")
          ) {
            Text("Ver Menú Deligurt 🍦", color = TextOnMint, fontWeight = FontWeight.Bold)
          }
        }
      } else {
        // Items List
        LazyColumn(
          modifier = Modifier
            .weight(1f, fill = false)
            .padding(horizontal = 18.dp, vertical = 6.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(cartItems, key = { it.id }) { item ->
            ClayCard(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("cart_item_${item.id}"),
              shape = RoundedCornerShape(20.dp),
              backgroundColor = Color.White,
              elevation = 4.dp
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.Top,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(modifier = Modifier.weight(1f)) {
                    Text(text = item.emoji, fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = item.productName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark
                      )
                      Text(
                        text = "Tamaño: ${item.sizeName}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MintDark
                      )
                    }
                  }

                  Text(
                    text = WhatsAppUtil.formatCurrency(item.totalPrice),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = TextDark
                  )
                }

                // Customization Details
                if (item.includedToppingsText.isNotBlank()) {
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = "• Toppings: ${item.includedToppingsText}",
                    fontSize = 11.sp,
                    color = TextMuted,
                    lineHeight = 15.sp
                  )
                }

                if (item.extraToppingsText.isNotBlank()) {
                  Text(
                    text = "• Extra (+${WhatsAppUtil.formatCurrency(item.extraToppingsPrice)}): ${item.extraToppingsText}",
                    fontSize = 11.sp,
                    color = StrawberryPink,
                    lineHeight = 15.sp
                  )
                }

                if (item.edibleSpoonText.isNotBlank() && !item.edibleSpoonText.contains("Sin cuchara", true)) {
                  Text(
                    text = "• ${item.edibleSpoonText} (+${WhatsAppUtil.formatCurrency(item.edibleSpoonPrice)})",
                    fontSize = 11.sp,
                    color = Color(0xFFD97706)
                  )
                }

                if (item.specialNotes.isNotBlank()) {
                  Text(
                    text = "• Nota: \"${item.specialNotes}\"",
                    fontSize = 11.sp,
                    color = Color(0xFF475569),
                    fontWeight = FontWeight.Medium
                  )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quantity Modifier Controls
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.End
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                      .clip(RoundedCornerShape(12.dp))
                      .background(Color(0xFFF1F5F9))
                      .padding(horizontal = 4.dp, vertical = 2.dp)
                  ) {
                    IconButton(
                      onClick = {
                        if (item.quantity > 1) {
                          onUpdateQuantity(item.id, item.quantity - 1)
                        } else {
                          onRemoveItem(item.id)
                        }
                      },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(
                        imageVector = if (item.quantity > 1) Icons.Default.Remove else Icons.Default.DeleteOutline,
                        contentDescription = "Disminuir",
                        tint = if (item.quantity > 1) TextDark else StrawberryPink,
                        modifier = Modifier.size(16.dp)
                      )
                    }

                    Text(
                      text = item.quantity.toString(),
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextDark,
                      modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    IconButton(
                      onClick = { onUpdateQuantity(item.id, item.quantity + 1) },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Aumentar",
                        tint = TextDark,
                        modifier = Modifier.size(16.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // ORDER SUMMARY & CHECKOUT BUTTON
        ClayCard(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp),
          shape = RoundedCornerShape(24.dp),
          backgroundColor = Color.White,
          elevation = 8.dp
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(18.dp)
          ) {
            // Subtotal
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Subtotal", fontSize = 13.sp, color = TextMuted)
              Text(
                text = WhatsAppUtil.formatCurrency(subtotal),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextDark
              )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Domicilio / Delivery
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Domicilio", fontSize = 13.sp, color = TextMuted)
                if (deliveryFee == 0) {
                  Spacer(modifier = Modifier.width(6.dp))
                  ClayBadge(text = "GRATIS", backgroundColor = MintPrimary)
                }
              }
              Text(
                text = if (deliveryFee == 0) "$ 0" else WhatsAppUtil.formatCurrency(deliveryFee),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (deliveryFee == 0) MintDark else TextDark
              )
            }

            if (subtotal < 45000) {
              val difference = 45000 - subtotal
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "✨ Agrega ${WhatsAppUtil.formatCurrency(difference)} más para envío GRATIS.",
                fontSize = 11.sp,
                color = MintDark,
                fontWeight = FontWeight.Medium
              )
            }

            HorizontalDivider(
              modifier = Modifier.padding(vertical = 10.dp),
              color = Color(0xFFF1F5F9)
            )

            // Total
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Total a pagar",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
              )
              Text(
                text = WhatsAppUtil.formatCurrency(total),
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = MintDark
              )
            }

            Spacer(modifier = Modifier.height(16.dp))

            ClayButton(
              onClick = onProceedToCheckout,
              backgroundColor = MintPrimary,
              modifier = Modifier
                .fillMaxWidth()
                .testTag("proceed_to_checkout_button")
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Continuar al Checkout",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextOnMint
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "💬", fontSize = 16.sp)
              }
            }
          }
        }
      }
    }
  }
}
