package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.CartItemEntity
import java.net.URLEncoder
import java.text.NumberFormat
import java.util.Locale

object WhatsAppUtil {

  // Default Deligurt delivery WhatsApp number
  const val DEFAULT_PHONE_NUMBER = "573123456789"

  fun formatCurrency(amount: Int): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale("es", "CO"))
    formatter.maximumFractionDigits = 0
    return formatter.format(amount)
  }

  fun generateWhatsAppMessage(
    customerName: String,
    customerPhone: String,
    address: String,
    neighborhood: String,
    deliveryNotes: String,
    paymentMethod: String,
    cashAmountToPayWith: String?,
    cartItems: List<CartItemEntity>,
    subtotal: Int,
    deliveryFee: Int,
    total: Int
  ): String {
    val builder = StringBuilder()

    builder.append("🍨 *NUEVO PEDIDO - DELIGURT APP* 🍨\n")
    builder.append("━━━━━━━━━━━━━━━━━━━━━━━━━\n\n")

    builder.append("👤 *DATOS DEL CLIENTE:*\n")
    builder.append("• *Nombre:* $customerName\n")
    if (customerPhone.isNotBlank()) {
      builder.append("• *Teléfono:* $customerPhone\n")
    }
    builder.append("• *Dirección:* $address\n")
    if (neighborhood.isNotBlank()) {
      builder.append("• *Barrio:* $neighborhood\n")
    }
    if (deliveryNotes.isNotBlank()) {
      builder.append("• *Indicaciones:* $deliveryNotes\n")
    }
    builder.append("\n━━━━━━━━━━━━━━━━━━━━━━━━━\n")
    builder.append("🛒 *DETALLE DEL PEDIDO:*\n\n")

    cartItems.forEachIndexed { index, item ->
      builder.append("${index + 1}. *${item.quantity}x ${item.productName} (${item.sizeName})*\n")
      if (item.includedToppingsText.isNotBlank()) {
        builder.append("   • *Toppings incluidos:* ${item.includedToppingsText}\n")
      }
      if (item.extraToppingsText.isNotBlank()) {
        builder.append("   • *Toppings extra (+${formatCurrency(item.extraToppingsPrice)}):* ${item.extraToppingsText}\n")
      }
      if (item.edibleSpoonText.isNotBlank() && !item.edibleSpoonText.contains("Sin cuchara", ignoreCase = true)) {
        builder.append("   • *Cuchara:* ${item.edibleSpoonText} (+${formatCurrency(item.edibleSpoonPrice)})\n")
      }
      if (item.specialNotes.isNotBlank()) {
        builder.append("   • *Nota especial:* ${item.specialNotes}\n")
      }
      builder.append("   *Subtotal item:* ${formatCurrency(item.totalPrice)}\n\n")
    }

    builder.append("━━━━━━━━━━━━━━━━━━━━━━━━━\n")
    builder.append("💵 *RESUMEN DE CUENTA:*\n")
    builder.append("• Subtotal: ${formatCurrency(subtotal)}\n")
    builder.append("• Domicilio: ${if (deliveryFee == 0) "¡GRATIS! 🎉" else formatCurrency(deliveryFee)}\n")
    builder.append("• *TOTAL A PAGAR: ${formatCurrency(total)}*\n\n")

    builder.append("💳 *MÉTODO DE PAGO:* *$paymentMethod*")
    if (paymentMethod.equals("Efectivo", ignoreCase = true) && !cashAmountToPayWith.isNullOrBlank()) {
      builder.append(" (Paga con: $cashAmountToPayWith - Alistar cambio)")
    }
    builder.append("\n\n━━━━━━━━━━━━━━━━━━━━━━━━━\n")
    builder.append("✨ _Pedido generado desde Deligurt App. ¡Quedo atento(a) a la confirmación del tiempo de entrega!_ 🍨")

    return builder.toString()
  }

  fun sendOrderToWhatsApp(
    context: Context,
    phoneWithCountryCode: String,
    message: String
  ): Boolean {
    val cleanPhone = phoneWithCountryCode.replace("[^0-9]".toRegex(), "")
    val encodedMessage = try {
      URLEncoder.encode(message, "UTF-8")
    } catch (e: Exception) {
      Uri.encode(message)
    }

    val url = "https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage"
    val intent = Intent(Intent.ACTION_VIEW).apply {
      data = Uri.parse(url)
    }

    return try {
      // Try WhatsApp specific packages first
      intent.setPackage("com.whatsapp")
      context.startActivity(intent)
      true
    } catch (e1: Exception) {
      try {
        intent.setPackage("com.whatsapp.w4b") // Business
        context.startActivity(intent)
        true
      } catch (e2: Exception) {
        try {
          // General browser/app fallback without forced package
          intent.setPackage(null)
          context.startActivity(intent)
          true
        } catch (e3: Exception) {
          copyToClipboard(context, message)
          Toast.makeText(
            context,
            "WhatsApp no detectado. El pedido fue copiado al portapapeles.",
            Toast.LENGTH_LONG
          ).show()
          false
        }
      }
    }
  }

  fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Pedido Deligurt", text)
    clipboard.setPrimaryClip(clip)
  }
}
