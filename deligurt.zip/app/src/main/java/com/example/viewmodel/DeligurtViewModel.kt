package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CartItemEntity
import com.example.data.DeligurtDatabase
import com.example.data.OrderEntity
import com.example.model.CatalogData
import com.example.model.EdibleSpoonType
import com.example.model.Product
import com.example.model.ProductCategory
import com.example.model.ProductSize
import com.example.model.Topping
import com.example.util.WhatsAppUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class DeligurtViewModel(application: Application) : AndroidViewModel(application) {

  private val database = DeligurtDatabase.getDatabase(application)
  private val cartDao = database.cartDao()
  private val orderDao = database.orderDao()

  // Selected Category Tab
  private val _selectedCategory = MutableStateFlow(ProductCategory.HELADOS_CLASICOS)
  val selectedCategory: StateFlow<ProductCategory> = _selectedCategory.asStateFlow()

  // Search and Filter query
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Products List
  val products: StateFlow<List<Product>> = _selectedCategory.map { category ->
    CatalogData.PRODUCTS.filter { it.category == category }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Cart Items from Room
  val cartItems: StateFlow<List<CartItemEntity>> = cartDao.getAllCartItems()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Cart Totals
  val cartSubtotal: StateFlow<Int> = cartItems.map { list ->
    list.sumOf { it.totalPrice }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  val deliveryFee: StateFlow<Int> = cartSubtotal.map { subtotal ->
    if (subtotal == 0) 0
    else if (subtotal >= 45000) 0 // Promo: Envío gratis en pedidos de $45.000+
    else 4000 // Tarifa estándar
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  val cartTotal: StateFlow<Int> = cartSubtotal.map { subtotal ->
    val fee = if (subtotal == 0 || subtotal >= 45000) 0 else 4000
    subtotal + fee
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  val cartItemCount: StateFlow<Int> = cartItems.map { list ->
    list.sumOf { it.quantity }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  // Order History from Room
  val orderHistory: StateFlow<List<OrderEntity>> = orderDao.getAllOrders()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Customization Dialog State
  private val _customizingProduct = MutableStateFlow<Product?>(null)
  val customizingProduct: StateFlow<Product?> = _customizingProduct.asStateFlow()

  private val _selectedSize = MutableStateFlow(ProductSize.MEDIANO)
  val selectedSize: StateFlow<ProductSize> = _selectedSize.asStateFlow()

  private val _selectedIncludedToppings = MutableStateFlow<List<Topping>>(emptyList())
  val selectedIncludedToppings: StateFlow<List<Topping>> = _selectedIncludedToppings.asStateFlow()

  private val _selectedExtraToppings = MutableStateFlow<List<Topping>>(emptyList())
  val selectedExtraToppings: StateFlow<List<Topping>> = _selectedExtraToppings.asStateFlow()

  private val _selectedEdibleSpoon = MutableStateFlow(EdibleSpoonType.NONE)
  val selectedEdibleSpoon: StateFlow<EdibleSpoonType> = _selectedEdibleSpoon.asStateFlow()

  private val _customizationNotes = MutableStateFlow("")
  val customizationNotes: StateFlow<String> = _customizationNotes.asStateFlow()

  // 3D Friendly Validation Dialog State
  private val _validationDialogMessage = MutableStateFlow<String?>(null)
  val validationDialogMessage: StateFlow<String?> = _validationDialogMessage.asStateFlow()

  // UI Navigation / Overlay Sheets
  private val _isCartSheetOpen = MutableStateFlow(false)
  val isCartSheetOpen: StateFlow<Boolean> = _isCartSheetOpen.asStateFlow()

  private val _isCheckoutOpen = MutableStateFlow(false)
  val isCheckoutOpen: StateFlow<Boolean> = _isCheckoutOpen.asStateFlow()

  private val _isHistoryOpen = MutableStateFlow(false)
  val isHistoryOpen: StateFlow<Boolean> = _isHistoryOpen.asStateFlow()

  // Checkout Fields
  var customerName = MutableStateFlow("")
  var customerPhone = MutableStateFlow("")
  var customerAddress = MutableStateFlow("")
  var customerNeighborhood = MutableStateFlow("")
  var deliveryNotes = MutableStateFlow("")
  var paymentMethod = MutableStateFlow("Nequi")
  var cashAmountToPay = MutableStateFlow("")

  // Business Phone
  val businessPhone = MutableStateFlow(WhatsAppUtil.DEFAULT_PHONE_NUMBER)

  init {
    // Load pre-saved customer info from SharedPreferences if available
    val prefs = application.getSharedPreferences("deligurt_prefs", Context.MODE_PRIVATE)
    customerName.value = prefs.getString("customer_name", "") ?: ""
    customerPhone.value = prefs.getString("customer_phone", "") ?: ""
    customerAddress.value = prefs.getString("customer_address", "") ?: ""
    customerNeighborhood.value = prefs.getString("customer_neighborhood", "") ?: ""
  }

  fun setCategory(category: ProductCategory) {
    _selectedCategory.value = category
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun openCustomization(product: Product) {
    _customizingProduct.value = product
    // Default size to available size
    val defaultSize = if (product.availableSizes.contains(ProductSize.MEDIANO)) {
      ProductSize.MEDIANO
    } else {
      product.availableSizes.firstOrNull() ?: ProductSize.PEQUENO
    }
    _selectedSize.value = defaultSize
    _selectedIncludedToppings.value = emptyList()
    _selectedExtraToppings.value = emptyList()
    _selectedEdibleSpoon.value = EdibleSpoonType.NONE
    _customizationNotes.value = ""
    _validationDialogMessage.value = null
  }

  fun closeCustomization() {
    _customizingProduct.value = null
    _validationDialogMessage.value = null
  }

  fun setSize(size: ProductSize) {
    _selectedSize.value = size
    // Trim included toppings if they exceed new size limit
    val product = _customizingProduct.value ?: return
    val requiredCount = product.getRequiredToppingsCount(size)
    if (requiredCount > 0 && _selectedIncludedToppings.value.size > requiredCount) {
      _selectedIncludedToppings.value = _selectedIncludedToppings.value.take(requiredCount)
    }
  }

  fun toggleTopping(topping: Topping) {
    val product = _customizingProduct.value ?: return
    val requiredCount = product.getRequiredToppingsCount(_selectedSize.value)
    val included = _selectedIncludedToppings.value.toMutableList()
    val extra = _selectedExtraToppings.value.toMutableList()

    if (included.any { it.id == topping.id }) {
      included.removeAll { it.id == topping.id }
      _selectedIncludedToppings.value = included
      return
    }

    if (extra.any { it.id == topping.id }) {
      extra.removeAll { it.id == topping.id }
      _selectedExtraToppings.value = extra
      return
    }

    // If product has strict mandatory count
    if (requiredCount > 0) {
      if (included.size < requiredCount) {
        included.add(topping)
        _selectedIncludedToppings.value = included
      } else if (product.allowsExtraToppings) {
        // Add as extra topping
        extra.add(topping)
        _selectedExtraToppings.value = extra
      }
    } else {
      // General product without strict mandatory count
      // First 2 are complimentary, others extra if allowsExtraToppings
      if (included.size < 2) {
        included.add(topping)
        _selectedIncludedToppings.value = included
      } else if (product.allowsExtraToppings) {
        extra.add(topping)
        _selectedExtraToppings.value = extra
      }
    }
  }

  fun setEdibleSpoon(spoon: EdibleSpoonType) {
    _selectedEdibleSpoon.value = spoon
  }

  fun setCustomizationNotes(notes: String) {
    _customizationNotes.value = notes
  }

  fun dismissValidationDialog() {
    _validationDialogMessage.value = null
  }

  fun confirmAddToCart() {
    val product = _customizingProduct.value ?: return
    val size = _selectedSize.value
    val requiredCount = product.getRequiredToppingsCount(size)

    // Check strict conditions
    if (requiredCount > 0) {
      val currentCount = _selectedIncludedToppings.value.size
      if (currentCount < requiredCount) {
        val missing = requiredCount - currentCount
        _validationDialogMessage.value = "¡Espera un momento! 🍨 Para tu ${product.name} en tamaño ${size.displayName} debes elegir exactamente $requiredCount toppings incluidos.\n\nTe falta(n) $missing topping(s) por seleccionar."
        return
      }
    }

    // Calculate unit price
    val baseAndSizePrice = product.basePrice + size.priceModifier
    val extraToppingsTotal = _selectedExtraToppings.value.size * product.extraToppingPrice
    val spoonPrice = _selectedEdibleSpoon.value.price
    val unitPrice = baseAndSizePrice + extraToppingsTotal + spoonPrice

    val includedText = _selectedIncludedToppings.value.joinToString(", ") { "${it.iconEmoji} ${it.name}" }
    val extraText = _selectedExtraToppings.value.joinToString(", ") { "${it.iconEmoji} ${it.name}" }

    val cartItem = CartItemEntity(
      productId = product.id,
      productName = product.name,
      categoryName = product.category.displayName,
      emoji = product.emoji,
      sizeName = size.displayName,
      sizePrice = baseAndSizePrice,
      includedToppingsText = includedText,
      extraToppingsText = extraText,
      extraToppingsPrice = extraToppingsTotal,
      edibleSpoonText = _selectedEdibleSpoon.value.displayName,
      edibleSpoonPrice = spoonPrice,
      specialNotes = _customizationNotes.value.trim(),
      quantity = 1,
      unitPrice = unitPrice,
      totalPrice = unitPrice
    )

    viewModelScope.launch {
      cartDao.insertCartItem(cartItem)
      closeCustomization()
    }
  }

  fun updateCartItemQuantity(id: Long, newQuantity: Int) {
    viewModelScope.launch {
      if (newQuantity <= 0) {
        cartDao.deleteCartItem(id)
      } else {
        cartDao.updateQuantity(id, newQuantity)
      }
    }
  }

  fun removeCartItem(id: Long) {
    viewModelScope.launch {
      cartDao.deleteCartItem(id)
    }
  }

  fun clearCart() {
    viewModelScope.launch {
      cartDao.clearCart()
    }
  }

  fun openCart() {
    _isCartSheetOpen.value = true
  }

  fun closeCart() {
    _isCartSheetOpen.value = false
  }

  fun openCheckout() {
    _isCartSheetOpen.value = false
    _isCheckoutOpen.value = true
  }

  fun closeCheckout() {
    _isCheckoutOpen.value = false
  }

  fun openHistory() {
    _isHistoryOpen.value = true
  }

  fun closeHistory() {
    _isHistoryOpen.value = false
  }

  fun submitOrderToWhatsApp(context: Context): Boolean {
    val items = cartItems.value
    if (items.isEmpty()) return false

    val name = customerName.value.trim()
    val address = customerAddress.value.trim()

    if (name.isBlank() || address.isBlank()) {
      return false
    }

    // Save preferences for future orders
    val prefs = getApplication<Application>().getSharedPreferences("deligurt_prefs", Context.MODE_PRIVATE)
    prefs.edit()
      .putString("customer_name", name)
      .putString("customer_phone", customerPhone.value.trim())
      .putString("customer_address", address)
      .putString("customer_neighborhood", customerNeighborhood.value.trim())
      .apply()

    val subtotal = cartSubtotal.value
    val fee = deliveryFee.value
    val total = cartTotal.value

    val message = WhatsAppUtil.generateWhatsAppMessage(
      customerName = name,
      customerPhone = customerPhone.value.trim(),
      address = address,
      neighborhood = customerNeighborhood.value.trim(),
      deliveryNotes = deliveryNotes.value.trim(),
      paymentMethod = paymentMethod.value,
      cashAmountToPayWith = if (paymentMethod.value == "Efectivo") cashAmountToPay.value.trim() else null,
      cartItems = items,
      subtotal = subtotal,
      deliveryFee = fee,
      total = total
    )

    // Record order in history
    val orderId = "DG-${UUID.randomUUID().toString().take(6).uppercase()}"
    val summary = items.joinToString("; ") { "${it.quantity}x ${it.productName} (${it.sizeName})" }

    val orderEntity = OrderEntity(
      orderId = orderId,
      timestamp = System.currentTimeMillis(),
      customerName = name,
      customerPhone = customerPhone.value.trim(),
      customerAddress = address,
      neighborhood = customerNeighborhood.value.trim(),
      notes = deliveryNotes.value.trim(),
      paymentMethod = paymentMethod.value,
      cashAmountToPayWith = cashAmountToPay.value.trim(),
      itemsSummary = summary,
      subtotal = subtotal,
      deliveryFee = fee,
      total = total,
      status = "Enviado a WhatsApp"
    )

    viewModelScope.launch {
      orderDao.insertOrder(orderEntity)
      cartDao.clearCart()
    }

    val success = WhatsAppUtil.sendOrderToWhatsApp(
      context = context,
      phoneWithCountryCode = businessPhone.value,
      message = message
    )

    _isCheckoutOpen.value = false
    return success
  }

  fun reorderPreviousOrder(order: OrderEntity) {
    // Quick re-order from history
    viewModelScope.launch {
      val defaultProduct = CatalogData.PRODUCTS.first()
      val reorderedItem = CartItemEntity(
        productId = defaultProduct.id,
        productName = order.itemsSummary.split(";").firstOrNull()?.trim() ?: "Pedido Anterior Deligurt",
        categoryName = "Reordenado",
        emoji = "🍨",
        sizeName = "Personalizado",
        sizePrice = order.subtotal,
        includedToppingsText = "Misma receta de pedido ${order.orderId}",
        extraToppingsText = "",
        extraToppingsPrice = 0,
        edibleSpoonText = "",
        edibleSpoonPrice = 0,
        specialNotes = "Reorden de ${order.orderId}",
        quantity = 1,
        unitPrice = order.subtotal,
        totalPrice = order.subtotal
      )
      cartDao.insertCartItem(reorderedItem)
      _isHistoryOpen.value = false
      _isCartSheetOpen.value = true
    }
  }
}
