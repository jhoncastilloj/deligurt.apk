package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {
  @Query("SELECT * FROM cart_items ORDER BY id DESC")
  fun getAllCartItems(): Flow<List<CartItemEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCartItem(item: CartItemEntity): Long

  @Query("UPDATE cart_items SET quantity = :quantity, totalPrice = unitPrice * :quantity WHERE id = :id")
  suspend fun updateQuantity(id: Long, quantity: Int)

  @Query("DELETE FROM cart_items WHERE id = :id")
  suspend fun deleteCartItem(id: Long)

  @Query("DELETE FROM cart_items")
  suspend fun clearCart()
}

@Dao
interface OrderDao {
  @Query("SELECT * FROM orders_history ORDER BY timestamp DESC")
  fun getAllOrders(): Flow<List<OrderEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: OrderEntity)
}

@Database(entities = [CartItemEntity::class, OrderEntity::class], version = 1, exportSchema = false)
abstract class DeligurtDatabase : RoomDatabase() {
  abstract fun cartDao(): CartDao
  abstract fun orderDao(): OrderDao

  companion object {
    @Volatile
    private var INSTANCE: DeligurtDatabase? = null

    fun getDatabase(context: Context): DeligurtDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          DeligurtDatabase::class.java,
          "deligurt_database"
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
