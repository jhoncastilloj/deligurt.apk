package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartItemEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val productId: String,
  val productName: String,
  val categoryName: String,
  val emoji: String,
  val sizeName: String,
  val sizePrice: Int,
  val includedToppingsText: String, // comma separated names
  val extraToppingsText: String, // comma separated names
  val extraToppingsPrice: Int,
  val edibleSpoonText: String,
  val edibleSpoonPrice: Int,
  val specialNotes: String,
  val quantity: Int,
  val unitPrice: Int,
  val totalPrice: Int
)

@Entity(tableName = "orders_history")
data class OrderEntity(
  @PrimaryKey
  val orderId: String,
  val timestamp: Long,
  val customerName: String,
  val customerPhone: String,
  val customerAddress: String,
  val neighborhood: String,
  val notes: String,
  val paymentMethod: String,
  val cashAmountToPayWith: String?,
  val itemsSummary: String,
  val subtotal: Int,
  val deliveryFee: Int,
  val total: Int,
  val status: String
)
