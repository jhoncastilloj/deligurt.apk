package com.example.model

enum class ProductCategory(val displayName: String, val icon: String) {
  HELADOS_CLASICOS("Helados Clásicos", "🍦"),
  ESPECIALIDADES("Especialidades", "⭐"),
  BEBIDAS_Y_MAS("Bebidas & Más", "🥤")
}

enum class ProductSize(val displayName: String, val subtitle: String, val priceModifier: Int) {
  PEQUENO("Pequeño", "6 oz - Porción personal", 0),
  MEDIANO("Mediano", "9 oz - El favorito", 4000),
  GRANDE("Grande", "14 oz - Para compartir", 8000)
}

enum class ToppingCategory(val displayName: String) {
  FRUTAS("🍓 Frutas Frescas"),
  CRUNCH("🍫 Crunch & Dulces"),
  SALSAS("🍯 Salsas & Drizzles")
}

data class Topping(
  val id: String,
  val name: String,
  val category: ToppingCategory,
  val iconEmoji: String,
  val isPopular: Boolean = false
)

enum class EdibleSpoonType(val displayName: String, val price: Int) {
  NONE("Sin cuchara comestible", 0),
  VAINILLA("Cuchara Vainilla Crocante", 1000),
  CANELA("Cuchara Canela & Miel", 1000),
  CHOCOLATE("Cuchara Chocolate Artesanal", 1000)
}

data class Product(
  val id: String,
  val name: String,
  val category: ProductCategory,
  val description: String,
  val basePrice: Int,
  val emoji: String,
  val badge: String? = null,
  val isLimitedEdition: Boolean = false,
  val availableSizes: List<ProductSize> = listOf(ProductSize.PEQUENO, ProductSize.MEDIANO, ProductSize.GRANDE),
  /**
   * Strict business logic rule:
   * Maps size to mandatory included toppings count.
   * e.g. For Fruping: Pequeño -> 3, Mediano -> 5, Grande -> 7.
   * Null if the product doesn't have strict mandatory toppings.
   */
  val mandatoryToppingsRules: Map<ProductSize, Int>? = null,
  val allowsCustomToppings: Boolean = true,
  val allowsExtraToppings: Boolean = true,
  val allowsEdibleSpoon: Boolean = true,
  val accentColorHex: Long = 0xFF00C49F
) {
  val extraToppingPrice = 2800

  fun getRequiredToppingsCount(size: ProductSize): Int {
    return mandatoryToppingsRules?.get(size) ?: 0
  }

  fun hasStrictToppingRules(): Boolean {
    return !mandatoryToppingsRules.isNullOrEmpty()
  }
}
