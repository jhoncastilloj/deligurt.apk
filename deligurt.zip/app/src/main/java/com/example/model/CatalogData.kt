package com.example.model

object CatalogData {

  val TOPPINGS: List<Topping> = listOf(
    // Frutas Frescas
    Topping("top_fresa", "Fresas Frescas", ToppingCategory.FRUTAS, "🍓", isPopular = true),
    Topping("top_kiwi", "Kiwi Rodajas", ToppingCategory.FRUTAS, "🥝"),
    Topping("top_mango", "Mango Dulce", ToppingCategory.FRUTAS, "🥭", isPopular = true),
    Topping("top_arandano", "Arándanos Azules", ToppingCategory.FRUTAS, "🫐", isPopular = true),
    Topping("top_durazno", "Durazno Almíbar", ToppingCategory.FRUTAS, "🍑"),
    Topping("top_banano", "Banano en Rodajas", ToppingCategory.FRUTAS, "🍌"),
    Topping("top_pina", "Piña Troceada", ToppingCategory.FRUTAS, "🍍"),

    // Crunch & Dulces
    Topping("top_brownie", "Brownie Bites", ToppingCategory.CRUNCH, "🍫", isPopular = true),
    Topping("top_oreo", "Galleta Oreo Troceada", ToppingCategory.CRUNCH, "🍪", isPopular = true),
    Topping("top_chispas", "Chispas de Chocolate", ToppingCategory.CRUNCH, "✨"),
    Topping("top_gomitas", "Gomitas Ácidas", ToppingCategory.CRUNCH, "🍬", isPopular = true),
    Topping("top_mms", "M&Ms Crocantes", ToppingCategory.CRUNCH, "🍭"),
    Topping("top_almendras", "Almendras Tostadas", ToppingCategory.CRUNCH, "🥜"),
    Topping("top_mani", "Maní Acaramelado", ToppingCategory.CRUNCH, "🌰"),
    Topping("top_granola", "Granola con Miel", ToppingCategory.CRUNCH, "🌾"),
    Topping("top_marshmallows", "Mini Marshmallows", ToppingCategory.CRUNCH, "☁️"),

    // Salsas & Drizzles
    Topping("top_salsa_maracuya", "Salsa Maracuyá Casera", ToppingCategory.SALSAS, "🍯", isPopular = true),
    Topping("top_salsa_choco", "Chocolate Fundido", ToppingCategory.SALSAS, "🍫", isPopular = true),
    Topping("top_arequipe", "Arequipe Tradicional", ToppingCategory.SALSAS, "🍮", isPopular = true),
    Topping("top_salsa_fresa", "Salsa Fresa Artesanal", ToppingCategory.SALSAS, "🍓"),
    Topping("top_condensada", "Leche Condensada", ToppingCategory.SALSAS, "🥛"),
    Topping("top_miel", "Miel Pura de Abejas", ToppingCategory.SALSAS, "🍯")
  )

  val PRODUCTS: List<Product> = listOf(
    // ESPECIALIDADES (con reglas estrictas e íconos)
    Product(
      id = "prod_fruping",
      name = "Fruping Deligurt",
      category = ProductCategory.ESPECIALIDADES,
      description = "Nuestra copa estrella: Yogurt cremoso helado con selección exacta de toppings frescos y crunchies según tu tamaño.",
      basePrice = 14500,
      emoji = "🍨",
      badge = "¡El Más Pedido!",
      accentColorHex = 0xFF00C49F,
      mandatoryToppingsRules = mapOf(
        ProductSize.PEQUENO to 3,
        ProductSize.MEDIANO to 5,
        ProductSize.GRANDE to 7
      ),
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    Product(
      id = "prod_frosty_blast",
      name = "Frosty Blast",
      category = ProductCategory.ESPECIALIDADES,
      description = "Explosión extrema de texturas: Base de helado de yogurt con capas intermedias de crunch y salsas premium.",
      basePrice = 15900,
      emoji = "💥",
      badge = "Favorito Crunch",
      accentColorHex = 0xFFFF5A79,
      mandatoryToppingsRules = mapOf(
        ProductSize.PEQUENO to 2,
        ProductSize.MEDIANO to 4,
        ProductSize.GRANDE to 6
      ),
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    Product(
      id = "prod_deli_ween",
      name = "Deli-Ween (Edición Especial)",
      category = ProductCategory.ESPECIALIDADES,
      description = "Edición limitada de temporada: Yogurt silvestre mora-arándano con veteado de cacao negro y toppings misteriosos.",
      basePrice = 17500,
      emoji = "🎃",
      badge = "Edición Limitada",
      isLimitedEdition = true,
      accentColorHex = 0xFF6B21A8,
      mandatoryToppingsRules = mapOf(
        ProductSize.PEQUENO to 3,
        ProductSize.MEDIANO to 4,
        ProductSize.GRANDE to 5
      ),
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    Product(
      id = "prod_parfait_crunch",
      name = "Parfait Crunch Deluxe",
      category = ProductCategory.ESPECIALIDADES,
      description = "Elegantes capas de yogurt cremoso, granola artesanal horneada con miel, fresas frescas y salsa de frutos rojos.",
      basePrice = 13900,
      emoji = "🍧",
      badge = "Fitness Choice",
      accentColorHex = 0xFFFFA500,
      mandatoryToppingsRules = null,
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    // HELADOS CLÁSICOS
    Product(
      id = "prod_clasico_natural",
      name = "Yogurt Suave Natural",
      category = ProductCategory.HELADOS_CLASICOS,
      description = "La receta original de Deligurt. 100% yogurt probiótico natural, textura aterciopelada y sabor balanceado.",
      basePrice = 9500,
      emoji = "🍦",
      badge = "Original",
      accentColorHex = 0xFF00C49F,
      mandatoryToppingsRules = null,
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    Product(
      id = "prod_fresa_delight",
      name = "Fresa Silvestre Delight",
      category = ProductCategory.HELADOS_CLASICOS,
      description = "Preparado con pulpa 100% natural de fresas silvestres seleccionadas. Cremoso, frutal e irresistible.",
      basePrice = 10500,
      emoji = "🍓",
      badge = "Frutal",
      accentColorHex = 0xFFFF5A79,
      mandatoryToppingsRules = null,
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    Product(
      id = "prod_maracuya_tropical",
      name = "Maracuyá Tropical Frost",
      category = ProductCategory.HELADOS_CLASICOS,
      description = "El balance cítrico perfecto de la fruta de la pasión con la suavidad del yogurt cremoso.",
      basePrice = 10500,
      emoji = "🥭",
      badge = "Cítrico",
      accentColorHex = 0xFFFFA500,
      mandatoryToppingsRules = null,
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    Product(
      id = "prod_choco_swirl",
      name = "Choco-Swirl Cremoso",
      category = ProductCategory.HELADOS_CLASICOS,
      description = "Helado suave con veteado profundo de chocolate semi-amargo al 60% cacao. Textura sublime.",
      basePrice = 11000,
      emoji = "🍫",
      badge = "Chocolover",
      accentColorHex = 0xFF78350F,
      mandatoryToppingsRules = null,
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    ),

    // BEBIDAS & MÁS
    Product(
      id = "prod_soda_maracuya",
      name = "Soda Maracuyá & Menta",
      category = ProductCategory.BEBIDAS_Y_MAS,
      description = "Soda italiana artesanal con pulpa natural de maracuyá, hojas frescas de menta machacadas y burbujas finas.",
      basePrice = 8900,
      emoji = "🥤",
      badge = "Refrescante",
      accentColorHex = 0xFF00C49F,
      availableSizes = listOf(ProductSize.MEDIANO, ProductSize.GRANDE),
      mandatoryToppingsRules = null,
      allowsCustomToppings = false,
      allowsExtraToppings = false,
      allowsEdibleSpoon = false
    ),

    Product(
      id = "prod_soda_frutos_rojos",
      name = "Soda Frutos Rojos Burbujeante",
      category = ProductCategory.BEBIDAS_Y_MAS,
      description = "Infusión gasificada artesanal con tropezones de fresas, moras y arándanos frescos.",
      basePrice = 9200,
      emoji = "🍹",
      badge = "Favorita",
      accentColorHex = 0xFFFF5A79,
      availableSizes = listOf(ProductSize.MEDIANO, ProductSize.GRANDE),
      mandatoryToppingsRules = null,
      allowsCustomToppings = false,
      allowsExtraToppings = false,
      allowsEdibleSpoon = false
    ),

    Product(
      id = "prod_smoothie_deligurt",
      name = "Smoothie Cremoso Deligurt",
      category = ProductCategory.BEBIDAS_Y_MAS,
      description = "Batido helado espeso a base de helado de yogurt y mix de frutas reales a tu elección.",
      basePrice = 12500,
      emoji = "🧋",
      badge = "Super Cremoso",
      accentColorHex = 0xFF8B5CF6,
      availableSizes = listOf(ProductSize.MEDIANO, ProductSize.GRANDE),
      mandatoryToppingsRules = null,
      allowsCustomToppings = true,
      allowsExtraToppings = true,
      allowsEdibleSpoon = true
    )
  )
}
